import Html exposing (text)

countElements : List a -> Int
countElements list =
    case list of
        [ ] ->
          0

        hd :: tl ->
          1 + countElements tl

lista = List.range 1 10

main =
        text ("List length = " ++ String.fromInt (countElements lista))

-- Mukaellen
-- https://johncrane.gitbooks.io/ninety-nine-elm-problems/content/lt/recursion_on_lists.html
