-- Combined a button and a text input in the same model
--
-- A text input for reversing text. Very useful!
--
-- Read how it works:
--   https://guide.elm-lang.org/architecture/text_fields.html
--
-- Press buttons to increment and decrement a counter.
--
-- Read how it works:
--   https://guide.elm-lang.org/architecture/buttons.html

import Browser
import Html exposing (Html, Attribute, button, div, p, input, text)
import Html.Attributes exposing (..)
import Html.Events exposing (onInput, onClick)


-- MAIN


main =
  Browser.sandbox { init = init, update = update, view = view }


-- MODEL


type alias Model =
  { content : String,
    count : Int
  }


init : Model
init =
  { content = ""
  , count = 10}


-- UPDATE

type Msg
  = Change String
  | Increment
  | Decrement


update : Msg -> Model -> Model
update msg model =
  case msg of
    Change newContent ->
      { model | content = newContent }
    
    Increment ->
      { model | count = model.count + 1}
      
    Decrement ->
      { model | count = model.count - 1}



-- VIEW

view : Model -> Html Msg
view model =
  div [style "padding" "1cm"]
    [ button [ onClick Increment ] [ text "+" ]
    , div [] [ text (String.fromInt model.count) ]
    , button [ onClick Decrement ] [ text "-" ]
    , p [] []
    , input [ placeholder "Text to reverse", value model.content, onInput Change ] []
    , div [style "font-size" "18px"] [
            p [style "color" "red"] [text (String.reverse model.content)] ]
    ]
