module Main exposing (blist, factorial, main, rawlist)

import Browser
import Html exposing (..)
import Html.Attributes exposing (..)


factorial : Int -> Int
factorial n =
    if n <= 0 then
        1

    else
        n * factorial (n - 1)


rawlist =
    List.range 1 10
        |> List.map
            (\x ->
                " Factorial "
                    ++ String.fromInt x
                    ++ "! = "
                    ++ String.fromInt (factorial x)
            )


blist =
    List.map (\w -> p [] [ text w ]) rawlist


main =
    div
        [ style "font-size" "1.5em"
        , style "color" "blue"
        , style "margin-left" "20%"
        , style "margin-right" "20%"
        ]
        blist
