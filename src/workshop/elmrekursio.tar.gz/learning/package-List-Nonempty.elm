> import List.Nonempty exposing (..)
> one : Nonempty Int
| one = fromElement 2
|   
Nonempty 2 [] : Nonempty Int
> two : Nonempty Int
| two = cons 4 one
|   
Nonempty 4 [2] : Nonempty Int
> toList two
[4,2] : List Int
> head two
4 : Int
> tail two
[2] : List Int
> toList (reverse two)
[2,4] : List Int
> toList (dropTail two)
[4] : List Int
> member 4 two
True : Bool
> foldl1 (+) two
6 : Int
"Alles klar!"
-- Oma keksintö:
> createNe : Int -> Nonempty Int
| createNe a = fromElement a
|
<function> : Int -> Nonempty Int
> createNe 3
Nonempty 3 [] : Nonempty Int
> List.singleton
<function> : a -> List a
> List.singleton "a"
["a"] : List String
> s = List.singleton "a"
["a"] : List String
> "b"::s
["b","a"] : List String
> List.reverse <| "b"::s
["a","b"] : List String
> > List.Nonempty.singleton
<function> : a -> Nonempty a
> List.Nonempty.singleton "c"
Nonempty "c" [] : Nonempty String
>
> List.Nonempty.singleton "d"
Nonempty "d" [] : Nonempty String
> List.Nonempty.toList
<function> : Nonempty a -> List a
> anel = List.Nonempty.singleton "d" |> List.Nonempty.toList
["d"] : List String
> "emppu"::anel
["emppu","d"] : List String
>
