module Main exposing (main)

import Browser
import Html exposing (..)
import Html.Events exposing (onClick)

angles = [15,30,45,60,75,90] 
acosd = \x -> 180*(acos x)/pi 
cosd = \x -> cos (pi*x/180)
sind = \x -> sin (pi*x/180.0)
decimfix = \x -> (toFloat (round (1000.0*x)))/1000.0
sinis = List.map sind angles |> List.map decimfix
     |> List.map String.fromFloat 

cosis = List.map cosd angles |> List.map decimfix
--"[0.259,0.5,0.707,0.866,0.966,1]"

main =
  div [] [
    text "Angles [15,30,45,60,75,90]"
    ,p [] [text ( sinis)]]
