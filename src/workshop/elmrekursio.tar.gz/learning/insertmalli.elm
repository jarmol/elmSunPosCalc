insertAt : Int -> a -> List a -> List a 
insertAt n z alist =
  (List.take (n - 1) alist) ++ (z :: List.drop (n - 1) alist)
<function> : Int -> a -> List a -> List a


numlist = List.range 1 5
[1,2,3,4,5] : List Int
insertAt 4 6 numlist
[1,2,3,6,4,5] : List Int
 
   
