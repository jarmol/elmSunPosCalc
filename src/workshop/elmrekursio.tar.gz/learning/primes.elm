import Debug exposing (toString)
import Html exposing (div, text, p)

primeList = [1,2,3,5,7,11,13,17,19,23,29,31]
makeNextList : Int -> List Int -> List Int
makeNextList iPrime aList =
   List.filter (\n -> remainderBy iPrime n > 0) aList

getListLength aList =
   "Length " ++ String.fromInt (List.length aList)

a0 = List.range 1 1000
a1 = makeNextList 2 a0
a2 = makeNextList 3 a1
a3 = makeNextList 5 a2
a4 = makeNextList 7 a3
a5 = makeNextList 11 a4
a6 = makeNextList 13 a5
a7 = makeNextList 17 a6
a8 = makeNextList 19 a7
a9 = makeNextList 23 a8
a10 = makeNextList 29 a9
a11 = makeNextList 31 a10

initialLength = getListLength a1
finalLength   = getListLength a11
filterLength  = " Filter " ++ getListLength primeList

main = div [] [
  text (Debug.toString a1)
  ,p [][text initialLength]
  ,p [][text (Debug.toString primeList ++ filterLength)]
  ,text ( Debug.toString (List.drop 1 a11))
  ,p [][text finalLength]
  ]

