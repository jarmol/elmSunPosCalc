module Main exposing (main)
import Html exposing (Html, li, ol, div, h1, text)
import Html.Attributes exposing (style)

mogules : List { name : String }
mogules =
    [ { name = "Jeff Bezos" }
    , { name = "Elon Musk" }
    , { name = "Sergey Brin" }
    , { name = "Larry Page" }
    , { name = "Steve Jobs" }
    , { name = "Bill Gates" }
    ]

addMr =
    (++) "Mr. "

printMogul mogul =
    li [] [ text (addMr mogul.name)
          ]

mogulsFormatted moguls =
    div [style "margin-left" "5%"] [ h1 [] [ text "Moguls" ]
           , ol [style "color" "blue", style "font-size" "150%"]
           (List.map printMogul moguls)
           ]
    
main : Html msg
main =
   mogulsFormatted mogules


-- From: https://medium.com/@ajdin.imsirovic/list-map-and-list-filter-in-elm-33fa6aab9ea5


