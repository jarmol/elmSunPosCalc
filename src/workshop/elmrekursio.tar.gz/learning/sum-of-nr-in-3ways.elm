List.foldl (\x a -> a + x) 0 (List.range 1 10)
List.range 1 10 |> List.foldl (\x a -> a + x) 0
List.foldl (\x a -> a + x) 0 <| List.range 1 10

