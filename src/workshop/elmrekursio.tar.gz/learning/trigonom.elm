module Trigonom exposing (main)

import Browser
import Html exposing (..)
import Html.Attributes exposing (..)

-- File trigonom.elm 
-- J. Lammi 21. March 2022

angles: List Float
angles = [0,7.5,15,22.5,30,37.5,45,52.5,60,67.5,75,82.5,90] 

zlist =  List.map (\x -> " sin(" ++String.fromFloat x ++ "°) = "
      ++ String.fromFloat ((sind x) |> roundFix)) angles 

wlist =  List.map (\x -> " cos(" ++String.fromFloat x ++ "°) = "
      ++ String.fromFloat ((cosd x) |> roundFix)) angles 

dlist = List.map (\w -> p [] [text w]) (zlist ++ wlist)

π: Float
π = pi

sind = \x -> sin (π*x/180.0)
cosd = \x -> cos (π*x/180.0)

roundFix: Float -> Float
roundFix = \x -> (toFloat (round (1.0E4*x)))/1.0E4

main = div [style "font-size" "1.25em",
            style "color" "blue", style "margin-left" "20%",
            style "margin-right" "20%"] dlist 

-- https://ellie-app.com/gZvMJ5JFnDMa1    
