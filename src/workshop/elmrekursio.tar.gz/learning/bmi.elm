module Main exposing (..)
-- Input a weight and length. Show calculated BMI.
--
-- Read how it works:
--   https://guide.elm-lang.org/architecture/forms.html
--

import Browser
import Html exposing (..)
import Html.Attributes exposing (..)
import Html.Events exposing (onInput)


-- MAIN

main =
  Browser.sandbox { init = init, update = update, view = view }

-- MODEL

type alias Model =
  { weightKG : String
  , lengthCM : String
  }


init : Model
init =
  Model "80" "168"


-- UPDATE

type Msg
  = WeightKG String
  | LengthCM String



update : Msg -> Model -> Model
update msg model =
  case msg of
    WeightKG weightKG ->
      { model | weightKG = weightKG }

    LengthCM lengthCM ->
      { model | lengthCM = lengthCM }


-- VIEW

getDecVar x =
    Maybe.withDefault 0 (String.toFloat x)
    
calcBMI model =
   let wgt = getDecVar model.weightKG
       hgt = getDecVar model.lengthCM / 100.0 -- cm -> m
       decThree = \x -> (1000*(x + 0.0005) |> floor |> toFloat ) / 1000.0
   in
     String.fromFloat <| decThree (wgt / hgt / hgt)
     
     
view : Model -> Html Msg
view model =
  div [style "margin-left" "1cm", style "margin-top" "1cm"]
    [ viewInput "text" "Weight (kg)" model.weightKG WeightKG
    , viewInput "text" "Length (cm)" model.lengthCM LengthCM
    , viewResult model
    ]


viewInput : String -> String -> String -> (String -> msg) -> Html msg
viewInput t p v toMsg =
  input [ type_ t, placeholder p, value v, style "width" "80px", onInput toMsg ] []


viewResult : Model -> Html msg
viewResult model =
   div  [ style "margin-left" "0.5cm"] [
   div  [ style "color" "green" ] [h2 [] [text  "Body Mass-Index" ]]
   ,table [][
   tr [ style "color" "blue" ] [ text ("Weight " ++ model.weightKG ++ " kg")]
   ,tr [ style "color" "blue" ] [ text ("Length " ++ model.lengthCM ++ " cm")]
   ,tr [ style "font-size" "120%"][ text ("BMI " ++ (calcBMI model))]]]

