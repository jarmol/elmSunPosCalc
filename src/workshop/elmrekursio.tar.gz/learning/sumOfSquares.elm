-- rekursiolla ja casen avulla looppi

sumOfSquares : Int -> Int
sumOfSquares n =
  case n of
    0 -> 0
    _ -> (n ^ 2) + sumOfSquares (n - 1)


-- Listafunktioilla ilman rekursiota

mapSqSum n =
   let
     square = \m -> m * m
   in
   List.range 1 n
   |> List.map square
   |> List.sum

-- mapSqSum 4 == 30

recursionmultify n =
   case n of
     1 -> 1
     _ -> n * recursionmultify (n - 1)


