module Main exposing (main)

import Html exposing (Html, div, h1, p, text)
import Html.Attributes exposing (..)
import List.Nonempty as Nonempty exposing (Nonempty)


type alias Triple =
    ( Int, Int, Int )


nextTriple : Triple -> Triple
nextTriple ( a, b, c ) =
    let
        anext =
            a + 2
        bnext =
            2 * a + b + 2
        cnext =
            2 * a + b + 3
    in
    ( anext, bnext, cnext )


printTriple ( a, b, c ) =
    let
        sa =
            String.fromInt a
        sb =
            String.fromInt b
        sc =
            String.fromInt c
    in
    "( " ++ sa ++ ", " ++ sb ++ ", " ++ sc ++ " )"


toParagraph : Triple -> Html msg
toParagraph t =
    p [] [ text (printTriple t) ]


init : Nonempty Triple
init =
    Nonempty.singleton ( 3, 4, 5 )


iterate : Int -> Nonempty Triple -> Nonempty Triple
iterate iterations soFar =
    case iterations of
        0 ->
            Nonempty.reverse soFar
        n ->
            let
                next : Triple
                next =
                    nextTriple (Nonempty.head soFar)
            in
            iterate (n - 1) (Nonempty.cons next soFar)


main : Html msg
main =
    div [style "margin-left" "5%", style "margin-top" "3em"]
        (h1 [] [ text "Pythagorean triples" ]
        :: (Nonempty.toList (iterate 8 init)
        |> List.map toParagraph))

-- [(3,4,5),(5,12,13),(7,24,25),(9,40,41),(11,60,61),(13,84,85),(15,112,113),(17,144,145),(19,180,181)]

-- https://ellie-app.com/hhz5p3vSmpXa1
