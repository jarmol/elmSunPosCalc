module Main exposing (..)

-- Press buttons to increment and decrement a counter.
-- Harjoitus: lisätään malliin reset (laskurin nollaus) ja msg +10 
-- Read how it works:
--   https://guide.elm-lang.org/architecture/buttons.html
--


import Browser
import Html exposing (Html, button, div, text)
import Html.Attributes exposing (style)
import Html.Events exposing (onClick)


-- MAIN

main =
  Browser.sandbox { init = init, update = update, view = view }


-- MODEL

type alias Model = Int


init : Model
init =
  0


-- UPDATE


type Msg
  = Increment
  | Decrement
  | Reset
  | IncTen


update : Msg -> Model -> Model
update msg model =
  case msg of
    Increment ->
      model + 1

    Decrement ->
      model - 1
      
    Reset ->
      init

    IncTen ->
      model + 10

-- VIEW


view : Model -> Html Msg
view model =
  div [style "margin-left" "10%", style "margin-top" "5em"]
    [ button [ onClick Decrement ] [ text "-" ]
    , div [] [ text (String.fromInt model) ]
    , button [ onClick Increment ] [ text "+" ]
    , div [style "padding-top" "1em"] [
      button [ onClick Reset ] [ text "reset" ]
    , div [] [
      button [ onClick IncTen] [ text "+10"]
    ]]]
