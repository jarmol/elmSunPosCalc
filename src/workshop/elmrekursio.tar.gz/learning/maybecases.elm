> Array.length
<function> : Array.Array a -> Int
> Array.length table
5 : Int
> table
Array.fromList [2,6,24,120,720]
    : Array.Array number
> 

> import Array exposing (fromList)
> mylist = List.range 1 6
[1,2,3,4,5,6] : List Int
> myArray = Array.fromList mylist
Array.fromList [1,2,3,4,5,6]
    : Array.Array Int
> Array.get 4 myArray
Just 5 : Maybe Int
> x = Array.get 4 myArray
Just 5 : Maybe Int
arrayInt : Maybe Int -> Int
arrayInt n =
  case n of
      Just currentN ->
        currentN
      Nothing ->
        0

<function> : Maybe Int -> Int
> x
Just 5 : Maybe Int
> arrayInt x
5 : Int
>  arrayItem array item =
|   Array.get item array
|   
<function> : Array.Array a -> Int -> Maybe a
> arrayItem myArray 5
Just 6 : Maybe Int
> arrayItem myArray 6
Nothing : Maybe Int
> myArray
Array.fromList [1,2,3,4,5,6]
    : Array.Array Int
 
u = [1, 2, 6, 24, 120, 720]
> tab = Array.fromList u
Array.fromList [1,2,6,24,120,720]
    : Array.Array number
> arrayItem tab 5
Just 720 : Maybe number
> arrayItem tab 5 |> arrayInt
720 : Int
> arrayItem tab 4 |> arrayInt
120 : Int
> arrayItem tab 3 |> arrayInt
24 : Int
> arrayItem tab 5 |> arrayInt |> (*) 7
5040 : Int

-- https://dennisreimann.de/articles/elm-maybe.html
> duplicate list =
|   case list of
|           [] ->
|               []
|           x :: xs ->
|               x :: x :: duplicate xs
|
<function> : List a -> List a
> u = [1, 2, 6, 24, 120, 720]
[1,2,6,24,120,720]
    : List number
> duplicate u
[1,1,2,2,6,6,24,24,120,120,720,720]
    : List number
>
> duplicate2 : List a -> List a
| duplicate2  list =
|       List.concatMap (\x -> [x, x]) list
|   
<function> : List a -> List a
> duplicate2 u
[1,1,2,2,6,6,24,24,120,120,720,720]
    : List number
> 
> duplicate3 : List a -> List a
| duplicate3 list =
|       List.foldl (\x y -> y ++ [x, x]) [] list
|   
<function> : List a -> List a
> duplicate3 u
[1,1,2,2,6,6,24,24,120,120,720,720]
    : List number

