module Main exposing (Geolocation, tornio)
import Html exposing(..)
import Html.Attributes exposing (..)
-- Määritellään paikkakunnan aliastyyppi
-- Huom. automaattisesti lisätty module.


type alias Geolocation =
    { latitude : Float, longitude : Float, timezone : Int, city : String }



-- Luodaan uusi paikka edellä määritetylle tyypille
-- Huom. aliastyyppi Geolocation toimii kuten funktio, joka
-- yksinkertaistaa uusien paikkojen lisäämisen.


tornio =
    Geolocation 65.85 24.18 2 "Tornio"

tampere = Geolocation 61.5 23.75 2 "Tampere"

-- Access a field
c1 = tornio.city

-- Special acessor functions
lat1 = .latitude tornio

lon2 = .longitude tampere

main=
    div [style "margin-left" "10%", style "font-size" "1.5em"]
    [text (c1 ++ "  latitudi " ++ String.fromFloat lat1)
    , p[] [text (tampere.city ++ " latitudi "
                 ++ String.fromFloat tampere.latitude)]]

-- Ref. https://elmprogramming.com/record.html
