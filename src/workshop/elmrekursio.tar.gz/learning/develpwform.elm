module Main exposing(..)

-- A text input for reversing text
-- Renamed model, init, update, msg and view
-- Extended validation of passwords
--   https://guide.elm-lang.org/architecture/text_fields.html

import Browser
import Html exposing (Html, Attribute, div, input, text)
import Html.Attributes exposing (..)
import Html.Events exposing (onInput)

-- MAIN

-- See original version
-- https://elm-lang.org/examples/text-fields

main =
  Browser.sandbox { init = preset, update = revise, view = monitor }


-- MODEL

type alias State =
  { name : String
  , password : String
  , passwordAgain : String
  }

preset : State
preset =
  State "" "" ""

-- UPDATE
-- Renamed Msg -> Message
-- update -> revise

type Message
  = Name String
  | Password String
  | PasswordAgain String

revise : Message -> State -> State
revise message state =
  case message of
    Name name ->
      { state | name = name }

    Password password ->
      { state | password = password }

    PasswordAgain password ->
      { state | passwordAgain = password }


-- VIEW

monitor : State -> Html Message
monitor state =
  div []
    [ viewInput "text" "Name" state.name Name
    , viewInput "password" "Password" state.password Password
    , viewInput "password" "Re-enter Password" state.passwordAgain PasswordAgain
    , viewValidation state
    ]


viewInput : String -> String -> String -> (String -> message) -> Html message
viewInput t p v toMsg =
  input [ type_ t, placeholder p, value v, onInput toMsg ] []

-- Validation of password: required:
-- min 8 char length
-- At least one lower case + upper case letters
-- and a special character

viewValidation : State -> Html message
viewValidation state =
  if String.length state.password > 7 then
     if state.password == state.passwordAgain then
        if String.any isDigit state.password then
           if String.any isLowerCase state.password then
              if String.any isUpperCase state.password then
                 if String.any isSpecial state.password then
                   div [ style "color" "green" ] [ text "OK" ]
                 else
                   div [ warn ] [ text ( pdnca ++ "special character!" )]
              else
                div [ warn ] [ text ( pdnca ++    "upper case letter!" )]
           else
             div [ warn ] [ text ( pdnca ++       "lower case letter!" )]
        else
          div [ warn ] [ text ( pdnca ++          "digit!" )]
     else
       div [ warn ] [ text "Passwords do not match!" ]
  else
    div [ warn ] [ text "Password is not long enough!" ]


isDigit : Char -> Bool
isDigit char =
   char >= '0' && char <= '9'


isLowerCase : Char -> Bool
isLowerCase char =
   char >= 'a' && char <= 'z'


isUpperCase : Char -> Bool
isUpperCase char =
   char >= 'A' && char <= 'Z'

isSpecial : Char -> Bool
isSpecial ch =
   not (isDigit ch) && not (isLowerCase ch) && not (isUpperCase ch)

warn = style "color" "red"
pdnca = "Password does not contain any "

-- Saved at https://ellie-app.com/j3cqdkc3ty6a1
