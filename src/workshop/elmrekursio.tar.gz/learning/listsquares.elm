import Html exposing (text)
import Debug exposing (toString)


mySquares : List number -> List number
mySquares list =
    case list of
        [ ] ->
          []

        x :: xs ->
          (mySquares xs) ++ [x * x]


lista = List.range 1 10

main = text ("Squares = "
  ++ Debug.toString (List.reverse <| mySquares lista))
