module Main exposing (main)

import Html exposing (..)
-- rekursion avulla tulo ilman looppia

factorial : Int -> Int
factorial n =
    if n <= 0 then 1 else n * factorial (n - 1)

main =
   text <| "Factorial 4 = " ++ String.fromInt ( factorial 4 )
      ++ ", factorial 5 = " ++ String.fromInt ( factorial 5 )
      ++ ", factorial 6 = " ++ String.fromInt ( factorial 6 )
      ++ ", factorial 7 = " ++ String.fromInt ( factorial 7 )
      ++ ", factorial 8 = " ++ String.fromInt ( factorial 8 )

-- factorial 4  -- shall print 24
-- factorial 5  -- shall print 120   

-- Käyttö
--  learning jarmo$ elm reactor
--  Go to http://localhost:8000 to see your project dashboard.


