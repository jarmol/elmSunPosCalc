import Debug exposing (toString)
import Html exposing (div, text, p)

mknxtLst : Int -> List Int -> List Int
mknxtLst iprime alist =
   List.filter (\n -> remainderBy iprime n > 0) alist

getLstLng aLst =
   "Found " ++ String.fromInt (List.length aLst) ++ " primes"

used : List Int
used = [2,3,5,7,11,13,17,19,23]
a0 = List.range 1 1000
a1 = mknxtLst 2 a0
a2 = mknxtLst 3 a1
a3 = mknxtLst 5 a2
a4 = mknxtLst 7 a3
a5 = mknxtLst 11 a4
a6 = mknxtLst 13 a5
a7 = mknxtLst 17 a6
a8 = mknxtLst 19 a7
a9 = mknxtLst 23 a8
t9 = used ++ (List.drop 1 a9)
p1 = List.take 40 t9
r1 = List.drop 40 t9
p2 = List.take 40 r1
r2 = List.drop 40 r1
p3 = List.take 40 r2
r3 = List.drop 40 r2
p4 = List.take 40 r3
r4 = List.drop 40 r3

l9 = getLstLng t9


main = div [] [
    text (Debug.toString p1)
    ,p [][text (Debug.toString p2)]
    ,p [][text (Debug.toString p3)]
    ,p [][text (Debug.toString p4)]
    ,p [][text (Debug.toString r4)]
    ,p [][text l9]
  ]

