import Browser
import Html exposing (..)
import Html.Attributes exposing(..)

type User
  = Regular String Int
  | Visitor String
  | Anonymous String

toName : User -> String
toName user =
  case user of
    Regular name age ->
      name
    Visitor name ->
      name
    Anonymous _ ->
      "anonymous"
 
thomas  = Regular "Thomas" 44
katie95 = Visitor "katie95"
anonyme = Anonymous "_" 

view =
  div [style "margin-left" "5%", style "margin-top" "5em"
  , style "font-size" "150%", style "color" "blue"] [ 
  text ("Hello " ++ toName thomas
    ++ ", " ++ toName katie95
    ++ " and " ++ toName anonyme)
    ]

main =
        view
