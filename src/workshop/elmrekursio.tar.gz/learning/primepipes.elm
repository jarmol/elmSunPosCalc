import Debug exposing (toString)
import Html exposing (div, text, p)

mknxtLst : Int -> List Int -> List Int
mknxtLst iprime alist =
   List.filter (\n -> remainderBy iprime n > 0) alist

getLstLng aLst =
   "Found " ++ String.fromInt (List.length aLst) ++ " primes"

used : List Int
used = [2,3,5,7,11,13,17,19,23,29,31]
a0 = List.range 1 1000
a11= mknxtLst 2 a0
  |> mknxtLst 3
  |> mknxtLst 5
  |> mknxtLst 7
  |> mknxtLst 11
  |> mknxtLst 13
  |> mknxtLst 17
  |> mknxtLst 19
  |> mknxtLst 23
  |> mknxtLst 29
  |> mknxtLst 31

-- all primes on one line
t11 = used ++ (List.drop 1 a11)

-- max 38 primes on a line
p1 = List.take 48 t11
r1 = List.drop 40 t11
p2 = List.take 40 r1
r2 = List.drop 40 r1
p3 = List.take 38 r2
r3 = List.drop 38 r2
p4 = List.take 38 r3
r4 = List.drop 38 r3

l11 = getLstLng t11


main = div [] [
    text (Debug.toString p1)
    ,p [][text (Debug.toString p2)]
    ,p [][text (Debug.toString p3)]
    ,p [][text (Debug.toString p4)]
    ,p [][text (Debug.toString r4)]
    ,p [][text l11]
  ]

