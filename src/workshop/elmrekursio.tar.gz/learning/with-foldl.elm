module Main exposing (..)

import Browser
import Html exposing (..)
import Html.Attributes exposing (..)


-- File factorial-with-foldl
-- J. Lammi 15. July 2021
-- recursion replaced by foldl
-- Impoved format 14. July the version with recursion by Peter Damoc, see Slack
-- see https://ellie-app.com/dK4GDmFDJqra1


factorial : Int -> Int
factorial n =
    List.foldl (\x a -> x * a) 1 <| List.range 1 n


viewFactorial : Int -> Html msg
viewFactorial x =
    p [] [ text (" Factorial " ++ String.fromInt x ++ "! = " ++ String.fromInt (factorial x)) ]


main =
    div [style "margin-left" "10%", style "color" "orange"]
        [ h1 [] [ text "Factorials with List.foldl"],
    div
        [ style "font-size" "1.5em"
        , style "color" "blue"
        , style "margin-left" "10%"
        , style "margin-right" "20%"
        ]
        (List.map viewFactorial (List.range 1 10))
        ] 
