module Main exposing (main)

import Html exposing (div, h1, p, text)
import Html.Attributes exposing (..)

nextTriple (a,b,c) =
        let anext = a + 2
            bnext = 2*a + b + 2
            cnext = 2*a + b + 3
        in
            (anext, bnext, cnext)

printTriple (a, b, c) =
        let sa = String.fromInt a
            sb = String.fromInt b
            sc = String.fromInt c
        in
            "( " ++ sa ++ ", " ++ sb ++ ", " ++ sc ++ " )" 

t1 = (3,4,5)
t2 = nextTriple t1
t3 = nextTriple t2
t4 = nextTriple t3
t5 = nextTriple t4
t6 = nextTriple t5
t7 = nextTriple t6
t8 = nextTriple t7

makeLists =
   let lista = List.range 0 12
   in
      List.map (\n -> 2*n +1) lista
-- [1,3,5,7,9,11,13,15,17,19,21,23,25]

sayHello : Int -> String
sayHello n =
   case n of
     1 -> "Triple: " ++ printTriple t1
     _ -> "Triple: " ++ String.fromInt (n) ++ " " ++ printTriple (nextTriple t1)
       ++ sayHello(n-1)


main =
        div [] [
          h1 [] [text "Pythagorean triples"]
          ,p [] [text (sayHello 3)]
          ,p [] [text (printTriple t1)]
          ,p [] [text (printTriple t2)]
          ,p [] [text (printTriple t3)]
          ,p [] [text (printTriple t4)]
          ,p [] [text (printTriple t5)]
          ,p [] [text (printTriple t6)]
          ,p [] [text (printTriple t7)]
          ,p [] [text (printTriple t8)]
        ]
