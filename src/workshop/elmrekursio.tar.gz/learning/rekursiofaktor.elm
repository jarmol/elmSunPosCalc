import Html exposing (div, text, h1, p)
import Html.Attributes exposing (style)

factorial n =
  if n <= 1 then
    1
  else
    n * factorial (n - 1)

cmore n =  
  p [] [text ("factorial " ++ String.fromInt n
  ++ " = " ++ String.fromInt (factorial n))]

crecurs n =
   case n of
      2 -> ", factorial 2 = 2 "
      _ -> ", factorial " ++ String.fromInt n ++ " = " ++ String.fromInt (factorial n) ++ crecurs (n - 1)
 

main = div [style "margin-left" "5%", style "color" "blue"] [
  h1 [][text "Factorials"]
  ,p [] [text (crecurs 12)]
  ]
  
-- Function factorial from
-- https://functional-programming-in-elm.netlify.app/recursion/tail-call-elimination.html
