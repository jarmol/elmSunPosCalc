scanl : (a -> b -> b) -> b -> List a -> List b
scanl fn b =
    let
        scan a bs =
            case bs of
                hd :: tl ->
                    fn a hd :: bs
                _ ->
                    []
    in
    List.foldl scan [b] >> List.reverse

scanl (+) 0 [1,2,3,4]

lista = List.range 0 12

listodd = List.map (\n -> 2*n +1) lista
-- [1,3,5,7,9,11,13,15,17,19,21,23,25]

sumscanodds = scanl (+) 0 listodd
-- [0,1,4,9,16,25,36,49,64,81,100,121,144,169]
-- Triples:
--     [9,16,25] -> (3,4,5)
-- New idea to primitive triples
--  a   b   c
--  3   4   5
--  5  12  13
--  7  24  25
--  9  40  41
-- 11  60  61
-- 13  84  85
-- 15 112 113
-- 17 144 145
-- 19 180 181
-- 21 220 221
-- 23 264 265
-- 25 312 313

nextTriple: (Int, Int, Int) -> (Int, Int, Int)
nextTriple (a1, b1, c1) =
      let
        a2 = a1 + 2
        b2 = 2*a1 + b1 + 2
        c2 = 2*a1 + b1 + 3
      in
        (a2, b2, c2)



