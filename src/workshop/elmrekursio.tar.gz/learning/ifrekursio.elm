import Html exposing (Html, div, h1, p, text)
import Html.Attributes exposing (style)
import Debug exposing (toString)

fact : Int -> Int
fact n =
  if (n < 2) then 1
  else n * (fact (n - 1))


showfact : Int -> String
showfact n =
  "factorial " ++ String.fromInt n ++ " = " ++ String.fromInt (fact n)

textshow : Int -> (Html msg)
textshow n =
        p [] [text (showfact n)]

main = div [style "margin-left" "5%"] [h1 [] [text "Factorials"]
  ,textshow 3
  ,textshow 4 
  ,textshow 5 
  ,textshow 6 
  ,textshow 7
  ,textshow 8 
  ,textshow 9 
  ]

