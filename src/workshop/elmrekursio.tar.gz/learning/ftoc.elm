module Ftocdegrees exposing (main)

import Browser
import Html exposing (..)
import Html.Attributes exposing (..)
import Html.Events exposing (onInput)


{-| Convert temperatures in
Fahrenheit to Celsius
degrees
-}



-- MAIN


main =
    Browser.sandbox { init = init, update = update, view = view }



-- MODEL


type alias Model =
    { input : String
    }


init : Model
init =
    { input = "" }



-- UPDATE


type Msg
    = Change String


update : Msg -> Model -> Model
update msg model =
    case msg of
        Change newInput ->
            { model | input = newInput }



-- VIEW


view : Model -> Html Msg
view model =
    case String.toFloat model.input of
        Just fahrenheit ->
            viewConverter model.input "blue"
             (String.fromFloat ((fahrenheit - 32) / 1.8))

        Nothing ->
            viewConverter model.input "red" "???"


viewConverter : String -> String -> String -> Html Msg
viewConverter userInput color equivalentTemp =
    div [ style "margin-top" "2em", style "margin-left" "10%" ]
        [ h1 [style "color" "red"] [ text "Converting F to C degrees" ]
        , input [ value userInput, onInput Change, style "width" "40px" ] []
        , text " °F = "
        , span [ style "color" color ] [ text equivalentTemp ]
        , text " °C"
        ]
