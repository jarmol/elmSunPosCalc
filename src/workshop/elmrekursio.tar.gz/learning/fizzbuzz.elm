module Main exposing (main)

import Browser
import Html exposing (text)

fizzBuzz = "FizzBuzz"
fizz = "Fizz"
buzz = "Buzz"

fizzBuzzInput value =
    if modBy 15 value == 0 then
        fizzBuzz
    else if modBy 5 value == 0 then
        buzz
    else if modBy 3 value == 0 then
        fizz
    else (String.fromInt value)
    
main = 
    text (fizzBuzzInput 30)

