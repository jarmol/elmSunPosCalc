import Html exposing (div, text, h1, p)
import Html.Attributes exposing (style)

factorial n =
  if n <= 1 then
    1
  else
    n * factorial (n - 1)

cmore n =  
  p [] [text ("factorial " ++ String.fromInt n
  ++ " = " ++ String.fromInt (factorial n))]

main = div [style "margin-left" "5%", style "color" "blue"] [
  h1 [][text "Factorials"]
  , cmore 3
  , cmore 4
  , cmore 5
  , cmore 6
  , cmore 7
  , cmore 8
  , cmore 9
  , cmore 10
  , cmore 11
  , cmore 12
  ]
  
-- Function factorial from
-- https://functional-programming-in-elm.netlify.app/recursion/tail-call-elimination.html
