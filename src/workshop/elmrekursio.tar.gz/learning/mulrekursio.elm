module Main exposing (main)

import Html exposing (..)
-- rekursion avulla tulo ilman looppia

mulRange start end acc =
    if start > end then
        acc
    else
        mulRange (start + 1) end (acc * start)

main =
   text <| "Multification " ++ String.fromInt ( mulRange 3 6 1 )

-- Ref. https://medium.com/@cscalfani/so-you-want-to-be-a-functional-programmer-part-1-1f15e387e536

