> pw
"ABCabc123" : String
> takeLcase = \c -> if (c >= 'a' && c <= 'z') then c else ' '
<function> : Char -> Char
> lowC = String.map takeLcase pw |> String.trim
"abc" : String
> takeUcase = \c -> if (c >= 'A' && c <= 'Z') then c else ' '
<function> : Char -> Char
> upCase = String.map takeUcase pw |> String.trim
"ABC" : String
> takeNumbers = \c -> if (c >= '0' && c <= '9') then c else ' '
<function> : Char -> Char
> numCase = String.map takeNumbers pw |> String.trim
"123" : String
> 
> String.filter (\c -> (c >= '0' && c <= '9')) pw
"123" : String
> String.filter (\c -> (c >= 'A' && c <= 'Z')) pw
"ABC" : String
> String.filter (\c -> (c >= 'a' && c <= 'z')) pw
"abc" : String

