import Html exposing (text)
import Debug exposing (toString)


mySquares : List number -> List number
mySquares list =
    List.map (\x -> x*x) list

lista = List.range 1 10

main = text ("Squares = "
  ++ Debug.toString ( mySquares lista ))
