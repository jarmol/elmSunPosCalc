module OutputPrimes exposing (main)

import Html  exposing (Html, h1, p, div, text)
import Html.Attributes exposing (..)
import Sieve as S

blist =  S.sieve 200000 202000

numbers = List.length blist

primes = List.map (String.fromInt) blist
        |> List.reverse
        |> List.map (\el -> " " ++ el)
        |> List.foldl (++) " "

main = div []
    [h1 [][text "PRIMES"]
    ,text primes
    ,p [] [text ("Found " ++ String.fromInt numbers ++ " primes")]
    ]
