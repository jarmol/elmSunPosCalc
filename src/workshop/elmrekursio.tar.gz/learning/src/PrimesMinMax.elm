module PrimesMinMax exposing (main)

import Browser
import Html  exposing (Html, input, button, h1, p, div, text)
import Html.Attributes exposing (..)
import Html.Events exposing (onInput, onClick)
import Html.Lazy 

type Color
    = White
    | Yellow
    | Blue
    | Black


type alias Model =
    { color : Color, textcolor : Color, min : String, max : String }

initialModel : Model
initialModel =
    { color = White, textcolor = Blue, min = "200000", max = "202280" }

type Msg
    = Toggle
    | ChangeMin String
    | ChangeMax String


update : Msg -> Model -> Model
update msg model =
    case msg of
        Toggle ->
            case model.color of
                White ->
                    { model | color = Yellow, textcolor = Black }

                Yellow ->
                    { model | color = Blue, textcolor = White }

                Blue   ->
                    { model | color = Black, textcolor = Yellow }

                Black  ->
                    { model | color = White, textcolor = Blue }
        
        ChangeMin min   ->
                    {model | min = min }

        ChangeMax max   ->
                    {model | max = max }



view : Model -> Html Msg
view model =
    div [ style "background-color" (toCssColor model.color)
        , style "color" (toTxtColor model.textcolor)
        , style "padding" "20px"]
        [ button [ onClick Toggle ] [ text "Toggle color" ]
        ,div []
        [ viewInput "number" "min" model.min ChangeMin
        , viewInput "number" "max" model.max ChangeMax 
        ,h1 [][text "PRIMES"]
        ,Html.Lazy.lazy2 getPrimesText  model.min model.max]
         ] 


viewInput : String -> String -> String -> (String -> msg) -> Html msg 
viewInput t p v toMsg =
    input [ type_ t, placeholder p, value v, style "width" "7em", onInput toMsg ] []


getPrimesText : String -> String -> Html msg
getPrimesText minS maxS =
    let min = Maybe.withDefault 2 (String.toInt minS)
        max = Maybe.withDefault 100 (String.toInt maxS)
        (primes, total) = getPrimes min max
    in   primes ++ " Found " ++ String.fromInt total |> text

getPrimes : Int -> Int -> (String, Int)
getPrimes min max =
    let
        blist =  sieve min max
        nprimes = List.length blist
        cstring =
            List.map (String.fromInt) blist
            |> List.reverse
            |> List.map (\el -> " " ++ el)
            |> List.foldl (++) " "
    in  (cstring, nprimes)


toCssColor : Color -> String
toCssColor color =
    case color of
        White ->
            "white"

        Yellow ->
            "yellow"

        Blue   ->
            "blue"

        Black  ->
            "black"

toTxtColor : Color -> String
toTxtColor textcolor =
    case textcolor of
        White ->
            "white"

        Yellow ->
            "yellow"

        Blue   ->  
            "blue"

        Black  ->  
            "black"



sieve : Int -> Int -> List Int
sieve min limit =
    let
        numbers =
            List.range 2 limit

        last =
            limit
                |> toFloat
                |> sqrt
                |> round

        isMultiple n m =
            n /= m && modBy m n == 0
    in
    List.range 2 last
        |> List.foldl
            (\current result ->
                List.filter
                    (\elem -> not (isMultiple elem current))
                    result
            )
            numbers

        |>  List.filter (\el -> el >= min)



main : Program () Model Msg
main =
    Browser.sandbox
        { init = initialModel
        , view = view
        , update = update
        }

-- Inspired of the article by juliu.is and the program
-- https://ellie-app.com/bc2KLQMsYkYa1
-- https://juliu.is/performant-elm-html-lazy/
-- My latest version https://ellie-app.com/jYwCHj45b3Sa1
-- My version: https://ellie-app.com/jRgMG5rs2Lha1
