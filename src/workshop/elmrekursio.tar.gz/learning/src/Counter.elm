module Counter exposing (Model)
import Html exposing (Html, h1, button, div, text)
import Html.Attributes exposing (..)
import Html.Events exposing (onClick)
import Browser

-- Laskurin malli on sovelluksen tila,
-- tyyppiä Model =  kokonaisluku alkuarvona 0

type alias Model =
    Int

initialModel : Model
initialModel =
    0

-- view lukee sovelluksen tilan ja palauttaa html-koodia
-- The view function takes a model and returns HTML code.

-- VIEW

view : Model -> Html Msg
view model =
    div [ style "color" "blue", style "margin-left" "10em",
          style "margin-top" "10em",
          style "font-size" "24px" ]
        [ h1 [] [ text "Counter"]
        , button [ onClick Decrement ] [ text "-" ]
        , text (" " ++ String.fromInt model ++ " ")
        , button [ onClick Increment ] [ text "+" ]
        ]


-- UPDATE

type Msg
    = Increment
    | Decrement


update : Msg -> Model -> Model
update msg model =
    case msg of
        Increment ->
            model + 1

        Decrement ->
            model - 1

-- As usual, main acts as an entry point for our app.

main : Program () Model Msg
main =
   Browser.sandbox { init = initialModel, update = update, view = view } 

-- https://elmprogramming.com/model-view-update-part-1.html
