module Sumandmulrekurs exposing(..)

sumOfNos: number -> number
sumOfNos n =
  if n==0 then 0
  else (n) + sumOfNos (n-1)
   
-- sumOfNos 10
-- 55 : number

mulOfNos: number -> number
mulOfNos n =
  if n == 1 then 1
  else (n) * mulOfNos (n - 1)
   
-- mulOfNos 4
-- 24 : number

