module FuncsMap2 exposing (sumProductOfLists, primesTo)


-- Functions using map2
-- Linear polynomes e.g.
-- [a, b, c] * [x, y, z]

sumProductOfLists : List number -> List number  -> number
sumProductOfLists coefficients arguments =
        List.map2 (\a x -> a * x) coefficients arguments
        |> List.sum

-- tests
-- sumProductOfLists [1,2,3,4] [10,5,10,5] == 70 : Float
-- sumProductOfLists [1.5,2.5,3.5,4.5] [10,4,2,2] == 41 : Float

primesTo m =
    let
        multiplesOf n =
            let
                go x =
                    if x <= m then
                        x :: go (x + n)

                    else
                        []
            in
            go n

        sieve nrs =
            case ( List.head nrs, List.tail nrs ) of
                ( Just x, Just xs ) ->
                    x :: sieve (List.filter (\y -> not (List.member y (multiplesOf x))) xs)

                _ ->
                    []
    in
    sieve (List.range 2 m)

