module Squares exposing (square, squares, inverse, inverses)
import  List exposing (map)
square = \n -> n*n
squares i = map (square) (List.range 1 i)

inverse = \n -> 1 / toFloat n
inverses j = map (inverse) (List.range 1 j)
