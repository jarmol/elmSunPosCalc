module ViewPrimes exposing (main)

import Browser
import Html  exposing (Html, button, h1, p, div, text)
import Html.Attributes exposing (style)
import Html.Events exposing (onClick)
import Html.Lazy 

type Color
    = White
    | Yellow


type alias Model =
    { color : Color }

initialModel : Model
initialModel =
    { color = White }

type Msg
    = Toggle


update : Msg -> Model -> Model
update msg model =
    case msg of
        Toggle ->
            case model.color of
                White ->
                    { model | color = Yellow }

                Yellow ->
                    { model | color = White }


view : Model -> Html Msg
view model =
    div [ style "background-color" (toCssColor model.color)
        , style "padding" "20px"]
        [ button [ onClick Toggle ] [ text "Toggle color" ]
        ,div []
        [ h1 [][text "PRIMES"]
         ,Html.Lazy.lazy2 getPrimesText 200000 202280]
         ] 

getPrimesText : Int -> Int -> Html msg
getPrimesText min max =
    getPrimes min max |> text

getPrimes : Int -> Int -> String
getPrimes min max =
    let
        blist =  sieve min max
    in  List.map (String.fromInt) blist
            |> List.reverse
            |> List.map (\el -> " " ++ el)
            |> List.foldl (++) " "


toCssColor : Color -> String
toCssColor color =
    case color of
        White ->
            "white"

        Yellow ->
            "yellow"


sieve : Int -> Int -> List Int
sieve min limit =
    let
        numbers =
            List.range 2 limit

        last =
            limit
                |> toFloat
                |> sqrt
                |> round

        isMultiple n m =
            n /= m && modBy m n == 0
    in
    List.range 2 last
        |> List.foldl
            (\current result ->
                List.filter
                    (\elem -> not (isMultiple elem current))
                    result
            )
            numbers

        |>  List.filter (\el -> el >= min)



main : Program () Model Msg
main =
    Browser.sandbox
        { init = initialModel
        , view = view
        , update = update
        }

-- Inspired of the article by juliu.is and the program
-- https://ellie-app.com/bc2KLQMsYkYa1
-- https://juliu.is/performant-elm-html-lazy/
-- My version: https://ellie-app.com/jRgMG5rs2Lha1
