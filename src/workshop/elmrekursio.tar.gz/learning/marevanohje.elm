module Main exposing (main)

import Browser
import Html exposing (Html, Attribute, h2, input, button, div, text, p)
import Html.Attributes exposing (..)
import Html.Events exposing (onClick, onInput)

type alias Model =
    { measured  : String
     , resultC  : String  
    }   

init : Model
init =
    { measured  = ""
     , resultC  = ""
    }   

type Msg 
    = Clicktoi
    | Measured String


-- Helper functions in updates

toDec: String -> Float
toDec sx =
    Maybe.withDefault 0.0 (String.toFloat sx) 

caseINR: Int -> String
caseINR index =
  case index of
    1  -> "Lisää viikkoannosta 15%."
          ++ " Toista INR- määritys 1-2 viikon päästä"
    2  -> "Lisää viikkoannosta 10%, jos INR alenee"
           ++ " toistuvissa mittauksissassa"
           ++ " tai kaksi peräkkäistä arvoa 1,5-1,9."
           ++ " INR-määritys 1-2 viikon päästä."
    3  ->  "Ei muutosta."
    4  ->  "Älä keskeytä marevania, pienennä"
           ++ " viikkoannosta 10%, jos INR noususuunnassa"
           ++ " tai kaksi peräkkäistä arvoa 3-3,9"
    5  ->  "Yhden päivän marevanin käytön tauko. "
           ++ "Pienennä viikkoannosta 10 %, "
           ++ "määritä INR 1–2 viikon päästä."
    6  ->  "Keskeytä marevanin annostelu. Anna suun kautta K-vitamiinia, "
           ++ "jos potilaan vuotoriski on suuri. Jos INR on vuorokauden"
           ++ " kuluttua edelleen korkea, anna lisää 1–2 mg K-vitamiinia."
           ++ " Aloita marevanin annostelua 15 % pienemmällä annoksella,"
           ++ " kun INR on hoitoalueella. Määritä INR viikottain,"
           ++ " kunnes antikoagulaatiotaso on vakaa."
    7  ->  "Keskeytä marevanin käyttö ja anna suun kautta 5–10 mg K-vitamiinia."
           ++ " Seuraa potilaan vointia tarkasti"
           ++ " ja anna tarvittaessa lisää K-vitamiinia."  
    _  ->  "Lääkärin ohjeiden mukaan"
    

marevan: Float -> Int
marevan inr =
     if (inr < 1.5)  then 1
     else if (inr >= 1.5 && inr <= 1.9) then 2
     else if (inr >= 2.0 && inr <= 3.0) then 3
     else if (inr >  3.0 && inr <= 3.9) then 4
     else if (inr >= 4.0 && inr <= 4.9) then 5
     else if (inr >  4.9 && inr <= 9.0) then 6
     else if  inr >  9.0 then 7
     else -1

inrInstruction: Float -> String
inrInstruction  x =
   marevan x |> caseINR


-- Example
-- > inrInstruction 2.5
-- "Ei muutosta"


update : Msg -> Model -> Model
update msg model =
    case msg of
        Clicktoi ->
            { model | resultC = inrInstruction <| toDec model.measured
            }

        Measured measured  ->
            { model | measured  =  measured }


view : Model -> Html Msg
view model =
    div [style "background-color" "black"
        , style "padding" "1em"
        , style "margin-left" "10%"
        , style "margin-right" "50%"]
        [ h2 [style "color" "yellow"]
        [text "MAREVANIN ANNOSTELUOHJEET"]
        , div [style "margin-left" "10%"
        , style "padding" "1em"
        , style "margin-right" "10%"
        , style "background-color" "blue"]
        [ input [ placeholder "INR-mittaus"
        , value model.measured
        , style "width" "6em"
        , onInput Measured] []
        , button [ onClick Clicktoi] [ text "INR-ohje" ]
        , p[] []
        , div [style "color" "white"] [ text <|  model.resultC ]
        , p[] []
        ]]



main : Program () Model Msg
main =
    Browser.sandbox
        { init = init
        , view = view
        , update = update
        }

-- J. Lammi 22.1.20211
