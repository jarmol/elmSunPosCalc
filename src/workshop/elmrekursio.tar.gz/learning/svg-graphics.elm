-- elm install elm/svg
import Html exposing (..)
import Svg exposing (..)
import Svg.Attributes exposing (..)


main : Html msg
main =
  svg
    [ viewBox "0 0 400 600"
    , width "400"
    , height "600"
    ]

    [ circle
        [ cx "180"
        , cy "100"
        , r "20"
        , fill "red"
        ]
        []

    , rect
        [ x "100"
        , y "380"
        , width "40"
        , height "40"
        , fill "green"
        , stroke "black"
        , strokeWidth "2"
        ]
        []

    , line
        [ x1 "80"
        , y1 "500"
        , x2 "280"
        , y2 "300"
        , stroke "blue"
        , strokeWidth "5"
        , strokeLinecap "round"
        ]
        []

    , polyline
        [ points "120,180 160,180 160,220 200,220 200,260 240,260"
        , fill "none"
        , stroke "red"
        , strokeWidth "4"
        , strokeDasharray "20,2"
        ]
        []

    , text_
        [ x "-25"
        , y "380"
        , fill "black"
        , textAnchor "middle"
        , dominantBaseline "central"
        , transform "rotate(-45 130,130)"
        ]
        [ Svg.text "Welcome to Shapes Club"
        ]
    ]



-- There are a lot of odd things about SVG, so always try to find examples
-- to help you understand the weird stuff. Like these:
--
--   https://www.w3schools.com/graphics/svg_examples.asp
--   https://developer.mozilla.org/en-US/docs/Web/SVG/Attribute/d
--
-- If you cannot find relevant examples, make an experiment. If you push
-- through the weirdness, you can do a lot with SVG.
