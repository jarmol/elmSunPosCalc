module Main exposing (main)

import Browser
import Html exposing (Html, Attribute, button, div, text)
import Html.Attributes exposing (..)
import Html.Events exposing (onClick)
import Squares

type alias Model =
    { squares :  List Float
    , inverses : List Float
    , results  : String
    }

init : Model
init =
    { squares =  [] 
    , inverses = []
    , results  = ""
    }

type Msg
    = Squares
    | Inverses
     
-- Helper functions in updates

toSquares mod =
   let content = String.join  " < " 
        <| List.map (String.fromInt)
        <| Squares.squares 20
   in
     "[ " ++ content ++ " ]"


toInverses mod =
   let content = String.join  " > "
        <| List.map (formateDecNum) 
        <| Squares.inverses 15
   in
     "[ " ++ content ++ " ]"



update : Msg -> Model -> Model
update msg model =
    case msg of
        Squares ->
            { model | results = toSquares model }

        Inverses ->
            { model | results = toInverses model }


view : Model -> Html Msg
view model =
    div []
        [ button [ onClick Squares]  [ text "Square List" ]
        , button [ onClick Inverses] [ text "Inverse List" ]
        , div [] [ text <| "Result " ++ model.results ]
        ]


nice x =
   1.0e-4 * (toFloat <| floor <| 1.0e4 * x + 0.5)


-- Cut to six long decimal part

formateDecNum nr =
    let 
        snr = String.fromFloat nr
        dotIndex = String.indices "." snr 
        dotNr = Maybe.withDefault 0 (List.minimum dotIndex)
        decNrLength = String.length snr 
        decimPart = String.slice dotNr decNrLength snr 
        cutTo6 = String.left 7 decimPart
        intPart = String.left dotNr snr 
    in  
        intPart ++ cutTo6


main : Program () Model Msg
main =
    Browser.sandbox
        { init = init
        , view = view
        , update = update
        }


