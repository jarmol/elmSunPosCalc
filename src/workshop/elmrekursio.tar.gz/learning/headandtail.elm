> y
[2,3,4,5,6,7,8,9,10]
    : List Int
> xh = List.head y
Just 2 : Maybe Int
> x = Maybe.withDefault 0 xh
2 : Int
> z
[2] : List Int
> [x] ++ z
[2,2] : List Int
> List.tail y
Just [3,4,5,6,7,8,9,10]
    : Maybe (List Int)
> y2 = Maybe.withDefault [] (List.tail y)
[3,4,5,6,7,8,9,10]
    : List Int
> y2 ++ [x*x]
[3,4,5,6,7,8,9,10,4]
    : List Int
> 
