import Html exposing (text)
import Debug exposing (toString)


myReverse : List a -> List a
myReverse list =
    case list of
        [ ] ->
          []

        x :: xs ->
          (myReverse xs) ++ [x]


lista = List.range 1 10

main =
        text ("Reverse = " ++ Debug.toString (myReverse lista))
