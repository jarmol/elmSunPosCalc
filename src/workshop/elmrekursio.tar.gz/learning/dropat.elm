import Html exposing (Html, div, text, p)
import Html.Attributes exposing (style)
import List
import Debug
import Debug exposing (toString)

-- toString (List.range 1 9)
-- "[1,2,3,4,5,6,7,8,9]" : String

dropAt : Int -> List a -> List a
dropAt n list =
    -- your implementation here
    (List.take (n - 1) list) ++ (List.drop n list)


main : Html a
main =  
    div [style "margin-left" "5%", style "font-size" "2em", style "color" "blue"] [
    text
        <| case test of
            0 ->
                "Your implementation passed all tests."

            1 ->
                "Your implementation failed one test."

            x ->
                "Your implementation failed " ++ (String.fromInt x) ++ " tests."


    ,p [] [text ("dropAt 3 (List.range 1 10) = "
             ++ toString (dropAt 3 (List.range 1 10)))]]
--              = [ 1, 2, 4, 5, 6, 7, 8, 9, 10 ]


test : Int
test =
    List.length
        <| List.filter ((==) False)
            [ dropAt 2 [ 1, 2, 5, 5, 2, 1 ] == [ 1, 5, 5, 2, 1 ]
            , dropAt 3 (List.range 1 10) == [ 1, 2, 4, 5, 6, 7, 8, 9, 10 ]
            , dropAt 6 (List.range 1 5) == [ 1, 2, 3, 4, 5 ]
            , dropAt 0 (List.range 1 5) == [ 1, 2, 3, 4, 5 ]
            , dropAt -1 (List.range 1 5) == [ 1, 2, 3, 4, 5 ]
            , dropAt 1 (List.range 1 5) == [ 2, 3, 4, 5 ]
            , dropAt 2 [ "1", "2", "3", "4", "5" ] == [ "1", "3", "4", "5" ]
            ]
