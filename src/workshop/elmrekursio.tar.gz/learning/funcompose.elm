module Main exposing (main)

import Html exposing (..)
import Html.Attributes exposing (..)


main =
    div
        [ style "margin-top" "3em"
        , style "margin-left" "10em"
        , style "font-size" "2em"
        ]
        [ h2 [ style "color" "blue" ]
            [ text "(jako << kerro << summaus) 3" ]
        , text "summaus 3 + 4 = 7"
        , Html.p []
            [ Html.text "kerro 2*7 = 14" ]
        , Html.text "jako 14/3 = "
        , Html.text <|
            String.fromFloat <|
                (jako << kerro << summaus) 3
        ]


summaus x =
    x + 4


kerro x =
    2 * x


jako x =
    x / 3
