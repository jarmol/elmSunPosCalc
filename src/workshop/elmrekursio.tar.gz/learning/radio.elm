import Browser
import Html exposing (..)
import Html.Attributes exposing (..)
import Html.Events exposing (onClick)


main =
    Browser.sandbox
        { init = init
        , view = view
        , model = Model False 
        , update = update
        }


type alias Model =
    { playing : Bool
    , src : String
    }


init : Model
init =
  Model False "https://legacy.radioparadise.com/rp3.php?song_id=44006"

type Msg
    = Play 
    | Pause
 
update msg model =
    case msg of
        Play ->
            { model | playing = True }

        Pause ->
            { model | playing = False }

 
view : Model -> Html Msg
view model =
    if model.playing then
        playingView model
    else
       notPlayingView model


notPlayingView : Model -> Html Msg
notPlayingView model =
    button [ onClick Play ] [ text "Play" ]


playingView : Model -> Html Msg
playingView model =
    div []
        [ button [ onClick Pause ] [ text "Pause" ]
        , audio [ src model.src, autoplay True, controls True ] []
        ]


-- https://legacy.radioparadise.com/rp3.php?song_id=44006&mode=web
