# Suorita
curl -T "marevanohje.html" ftp://ftp.saunalahti.fi/public_html/ --user benefon
echo "Valmis!"
