> lista = List.map (\n -> 2*n + 1) (List.range 1 9)
 [3,5,7,9,11,13,15,17,19]
> listb = List.map (\n -> 2*n*(n + 1)) (List.range 1 9)
 [4,12,24,40,60,84,112,144,180]
> listc = List.map (\n -> 2*n*(n + 1) + 1) (List.range 1 9)
 [5,13,25,41,61,85,113,145,181]

> List.head lista |> Maybe.withDefault 0
 3 : Int
> List.head listb |> Maybe.withDefault 0
 4 : Int
> List.head listc |> Maybe.withDefault 0
 5 : Int
-- Thus the first triple is (3, 4, 5)
-- How to pick up the next triple (5, 12, 13)?
> List.tail lista |> Maybe.withDefault [0]
[5,7,9,11,13,15,17,19]  : List Int
> List.tail lista
Just [5,7,9,11,13,15,17,19]    : Maybe (List Int)
> List.tail listb |> Maybe.withDefault [0]
[12,24,40,60,84,112,144,180]    : List Int
> List.tail listc |> Maybe.withDefault [0]
[13,25,41,61,85,113,145,181]    : List Int
> List.tail lista |> Maybe.withDefault [0] |> List.head |> Maybe.withDefault 0
5 : Int
> List.tail listb |> Maybe.withDefault [0] |> List.head |> Maybe.withDefault 0
12 : Int
> List.tail listc |> Maybe.withDefault [0] |> List.head |> Maybe.withDefault 0
13 : Int
-- Too many steps needed until the next triple (a, b, c) = (5, 12, 13)
-- Maybe recursion can be used if the above steps are used
-- to construction of a helper function
> list =
     List.range 1 9
       |> List.map
         (\n ->
           ( 2*n + 1
           , 2*n*(n+1)
           , 2*n*(n+1) + 1
           )
         )
   
[(3,4,5),(5,12,13),(7,24,25),(9,40,41),(11,60,61),(13,84,85),(15,112,113),(17,144,145),(19,180,181)]
    : List ( Int, Int, Int )

> List.map3 (\a b c -> (a,b,c)) lista listb listc
[(3,4,5),(5,12,13),(7,24,25),(9,40,41),(11,60,61),(13,84,85),(15,112,113),(17,144,145),(19,180,181)]
    : List ( Int, Int, Int )

> tripleToString : (Int, Int, Int) -> String
| tripleToString (a, b, c) =
|   "(" ++ String.fromInt a ++ String.fromInt b ++ String.fromInt c ++ ")"
|
<function> : ( Int, Int, Int ) -> String

-- This works!
> List.map tripleToString list |> List.foldl (++) " "
"(19, 180, 181)(17, 144, 145)(15, 112, 113)(13, 84, 85)(11, 60, 61)(9, 40, 41)(7, 24, 25)(5, 12, 13)(3, 4, 5) "
    : String

