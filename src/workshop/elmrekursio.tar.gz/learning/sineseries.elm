module Main exposing (main)

import Browser
import Html exposing (Html, button, div, text, p)
import Html.Attributes exposing (style)
import FormatNumber exposing (..)
import FormatNumber.Locales exposing (..)

sindeg = \x -> sin (pi * x / 180.0)

san nd x = format { frenchLocale | decimals = Exact nd } x
form6 x = san 6 x
form8 x = san 8 x
form10 x = san 10 x
asind x = 180.0 / pi * asin x

sx = 45.0 * pi / 180.0
sf1 = form10 sx
sa1 = san 3 (asind sx)
sx2 = sx -  (sx^ 3) / 6
sf2 = form6 sx2
sa2 = san 4 (asind sx2)
sx3 = sx2 + (sx^ 5) / 120 
sf3 = form6 sx3
sa3 = san 4 (asind sx3)
sx4 = sx3 - (sx^ 7) / 5040
sf4 = form8 sx4
sa4 = form6 (asind sx4)
sx5 = sx4 + (sx^ 9) / 362880
sf5 = form10 sx5
sa5 = form8 (asind sx5)
sx6 = sx5 - (sx^ 11) / 39916800
sf6 = san 11 sx6
sa6 = form10 (asind sx6)

main =
    div [style "margin-left" "5%"
        , style "color" "blue"
        , style "font-size" "125%"]
    [
    text ("sin 45° = " ++ String.fromFloat (sindeg 45.0))
    ,p [] []
    ,text ("1/ √2 = " ++ String.fromFloat (2^ -0.5))
    ,p [][]
    ,text ("x = " ++ sf1 ++ " => asin = " ++ sa1 ++ " °")
    ,p [][]
    ,text ("x - x³ / 3! = " ++ sf2 ++ " => asin = " ++ sa2 ++ " °")
    ,p [][]
    ,text ("x - x³ / 3! + x⁵ / 5! = " ++ sf3 ++ " => asin = " ++ sa3 ++ " °")
    ,p [] []
    ,text ("x - x³ / 3! + x⁵ / 5! - x⁷ / 7! = " ++ sf4 ++ " => asin = " ++ sa4 ++ " °")
    ,p [] []
    ,text ("x - x³ / 3! + x⁵ / 5! - x⁷ / 7! + x⁹ / 9! = " ++ sf5 ++ " => asin = " ++ sa5 ++ " °")
    ,p [] []
    ,text ("x - x³ / 3! + x⁵ / 5! - x⁷ / 7! + x⁹ / 9! - x¹¹ / 11! = " ++ sf6 ++ " => asin = " ++ sa6 ++ " °")
    ]

-- https://ellie-app.com/hFWpbw6rTTka1
-- https://ellie-app.com/hDS9NZ3LFwLa1
-- https://ellie-app.com/hDCXLnCSBkqa1
