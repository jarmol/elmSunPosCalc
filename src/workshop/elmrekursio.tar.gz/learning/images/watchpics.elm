module PhotoGroove exposing (main)
import Html exposing (div, h1, img, text)
import Html.Attributes exposing (..)

pad5 = style "padding" "5px"
redH = style "color" "red"

view model =
   div [ class "content" ]
      [ h1 [pad5, redH] [ text "Photo Groove" ]
      , div [pad5, id "thumbnails" ]
         [ img [pad5, src "1.jpeg" ] []
         , img [pad5, src "2.jpeg" ] []
         , img [pad5, src "3.jpeg" ] []
      ] ]

main =
   view "no model yet"

-- https://livebook.manning.com/book/elm-in-action/chapter-2/35
