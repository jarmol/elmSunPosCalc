> lists
[[1],[2],[3,4,5],[6,7,8],[2,3],[4,5],[6,7,8,9,0]]
    : List (List number)
> import List exposing (map, sortBy, length)
> lists
[[1],[2],[3,4,5],[6,7,8],[2,3],[4,5],[6,7,8,9,0]]
    : List (List number)
> map length (sortBy length lists)
[1,1,2,2,3,3,5]
    : List Int

