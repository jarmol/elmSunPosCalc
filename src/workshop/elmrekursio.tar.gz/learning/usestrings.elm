import Squares as Sq exposing (..)
import Browser
import Html exposing (div, text, p)
import Html.Attributes exposing (..)

sq : Int -> String
sq n =
     ( String.join  ". " 
      <| List.map (String.fromInt)
      <| squares n)

inv : Int -> String
inv n = 
     ( String.join  ", " 
      <| List.map (String.fromFloat)
      <| inverses n) 

main =
   Html.text ((sq 20) ++ " Lisää " ++ (inv 6))
