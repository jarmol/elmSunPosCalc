module Main exposing (main)

-- Ajdin Imsirovic
-- Ref: https://www.codingexercises.com/guides/quickstart-elm-part-2
-- Quickstart Elm 0.19, parts 2 and 5

import Browser
import Html exposing (Html, button, div, text, h1)
import Html.Events exposing (onClick)


-- MODEL
type alias Model = 
    Int

-- INITIAL MODEL
initialModel =
    5

-- VIEW
view model =
    div [] [ h1 []
           [ text (" Fruits to eat: " ++ (String.fromInt model)) ]
           , button [ onClick Decrement ] [ text "Eat fruit" ]
           , button [ onClick Reset ] [ text "Reset counter" ]
           ]   

-- MESSAGE
type Msg = 
    Decrement | Reset

-- UPDATE

update msg model =
   case msg of
      Decrement ->
        if model > 1 then model - 1
        else 5
      Reset -> 5

-- main : HTML msg
main = Browser.sandbox
    { init = initialModel
    , update = update
    , view = view
    }

