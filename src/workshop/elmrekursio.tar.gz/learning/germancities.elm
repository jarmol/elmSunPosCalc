--- Elm 0.19.1 ----------------------------------------------------------------
Say :help for help and :exit to exit! More at <https://elm-lang.org/0.19.1/repl>
--------------------------------------------------------------------------------
> isGerman city = List.member city ["Berlin", "Dresden", "Hamburg"]
<function> : String -> Bool

> selected = List.filter isGerman ["Stockholm", "Dresden", "Helsinki", "Hamburg", "Zürich"]
["Dresden","Hamburg"] : List String
>
> ["Cities in Germany "] ++ selected
["Cities in Germany ","Dresden","Hamburg"]
