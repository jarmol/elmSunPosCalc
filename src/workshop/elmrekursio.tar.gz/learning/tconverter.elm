module Main exposing (main)

import Browser
import Html exposing (Html, Attribute, h2, input, button, div, text, p)
import Html.Attributes exposing (..)
import Html.Events exposing (onClick, onInput)

type alias Model =
    { degrees  : String  
    , resultF  : String
    , resultC  : String
    }

init : Model
init =
    { degrees  = ""
    , resultF  = ""
    , resultC  = ""
    }

type Msg
    = Clicktof
    | Clicktoc
    | Degrees String
    | Resultf String
    | Resultc String

-- Helper functions in updates

toDec: String -> Float
toDec sx =
    Maybe.withDefault 0.0 (String.toFloat sx)


toFdegrees mod =
   9.0 * (toDec mod.degrees) / 5.0 + 32.0
        
toCdegrees mod =
   5.0 * (toDec mod.degrees - 32.0) / 9.0

    
update : Msg -> Model -> Model
update msg model =
    case msg of
        Clicktof ->
            { model | resultC = model.degrees
            , resultF = formateDecNum <| toFdegrees model }

        Clicktoc ->
            { model | resultF = model.degrees
            , resultC = formateDecNum <| toCdegrees model }

        Degrees degrees ->
            { model | degrees = degrees }

        Resultc resultC ->
            { model | resultC = resultC }

        Resultf resultF ->
           { model | resultF = resultF } 


view : Model -> Html Msg
view model =
    div [style "background-color" "black"
        , style "margin-left" "10%"
        , style "margin-right" "50%"]
        [ h2 [style "color" "yellow"]
        [text "TEMPERATURES CONVERSION"]
        , div [style "margin-left" "17%"
        , style "margin-right" "17%"
        , style "background-color" "blue"]
        [ input [ placeholder "Temperature"
        , value model.degrees
        , style "width" "6em"
        , onInput Degrees] []
        , button [ onClick Clicktof] [ text "C -> F" ]
        , button [ onClick Clicktoc] [ text "F -> C" ]
        , p[] []
        , div [style "color" "white"] [ text <| "○  Temperature " ++ model.resultF ++ " ℉" ]
        , p[] []
        , div [style "color" "white"] [ text <| "○  Temperature " ++ model.resultC ++ " ℃" ]
        , p[] []
        , div [style "color" "black", style "background-color" "black"] [text "~"]
        ]]



-- Cut to two long decimal part

formateDecNum: Float -> String
formateDecNum nr =
    let 
        snr = String.fromFloat nr
        dotIndex = String.indices "." snr 
        dotNr = Maybe.withDefault 0 (List.minimum dotIndex)
        decNrLength = String.length snr 
        decimPart = String.slice dotNr decNrLength snr 
        cutTo3 = String.left 3 decimPart
        intPart = String.left dotNr snr 
    in  
        intPart ++ cutTo3


main : Program () Model Msg
main =
    Browser.sandbox
        { init = init
        , view = view
        , update = update
        }

-- J. Lammi
-- 2021-Jan-06
-- See https://ellie-app.com/bZSNjbLMWxba1

