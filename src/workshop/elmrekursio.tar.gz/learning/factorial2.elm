module Main exposing (main)
import Browser
import Html exposing (..)
import Html.Attributes exposing (..)

-- rekursion avulla tulo ilman looppia

factorial : Int -> Int
factorial n =
    if n <= 0 then 1 else n * factorial (n - 1)

main =
   div [style "font-size" "1.5em", style "color" "blue",
        style "margin-left" "10%"] [
   text "Kertoman laskeminen rekursion avulla", 
   p [] [], 
   text  ("2! = " ++ String.fromInt ( factorial 2 )),
   p [] [], 
   text  ("3! = " ++ String.fromInt ( factorial 3 )), 
   p [][],
   text  ("4! = " ++ String.fromInt ( factorial 4 )),
   p [][],
   text  ("5! = " ++ String.fromInt ( factorial 5 )),
   p [][],
   text  ("6! = " ++ String.fromInt ( factorial 6)),
   p [][],
   text  ("7! = " ++ String.fromInt ( factorial 7)),
   p [][],
   text  ("8! = " ++ String.fromInt ( factorial 8)),
   p [][],
   text  ("9! = " ++ String.fromInt ( factorial 9))]

-- factorial 4  -- shall print 24
-- factorial 5  -- shall print 120   

-- Käyttö
--  learning jarmo$ elm reactor
--  Go to http://localhost:8000 to see your project dashboard.


