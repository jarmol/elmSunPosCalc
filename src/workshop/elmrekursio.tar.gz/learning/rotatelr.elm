> (List.drop 0 list) ++ (List.take 0 list)
[1,2,3,4,5] : List Int
> (List.drop 1 list) ++ (List.take 1 list)
[2,3,4,5,1] : List Int
> (List.drop 2 list) ++ (List.take 2 list)
[3,4,5,1,2] : List Int
> (List.drop 3 list) ++ (List.take 3 list)
[4,5,1,2,3] : List Int
> (List.drop 4 list) ++ (List.take 4 list)
[5,1,2,3,4] : List Int
> (List.drop 5 list) ++ (List.take 5 list)
[1,2,3,4,5] : List Int
> (List.drop 6 list) ++ (List.take 6 list)
[1,2,3,4,5] : List Int
> (List.drop 0 (List.reverse list)) ++ (List.take 0 (List.reverse list)) |> List.reverse
[1,2,3,4,5] : List Int
> (List.drop 1 (List.reverse list)) ++ (List.take 1 (List.reverse list)) |> List.reverse
[5,1,2,3,4] : List Int
> (List.drop 2 (List.reverse list)) ++ (List.take 2 (List.reverse list)) |> List.reverse
[4,5,1,2,3] : List Int
> (List.drop 3 (List.reverse list)) ++ (List.take 3 (List.reverse list)) |> List.reverse
[3,4,5,1,2] : List Int
> (List.drop 4 (List.reverse list)) ++ (List.take 4 (List.reverse list)) |> List.reverse
[2,3,4,5,1] : List Int
> (List.drop 5 (List.reverse list)) ++ (List.take 5 (List.reverse list)) |> List.reverse
[1,2,3,4,5] : List Int

