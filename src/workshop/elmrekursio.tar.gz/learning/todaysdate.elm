module Main exposing (main)

import Browser
import Date exposing (Date, Unit(..), diff, fromCalendarDate)
import Time exposing (Month(..))
import Html exposing (Html, button, div, text, p)
import Html.Attributes exposing (..)
import Html.Events exposing (onClick)
import Task


type alias Model =
    { today : Maybe Date }


initialModel : ( Model, Cmd Msg )
initialModel =
    ( { today = Nothing }
    , Date.today
        |> Task.perform GotDate
    )


type Msg
    = GotDate Date


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        GotDate date ->
            ( { model | today = Just date }, Cmd.none )

ageMonths = diff Months
    (fromCalendarDate 1974 Mar 22)
    (fromCalendarDate 2022 Mar 22)

view : Model -> Html Msg
view model =
    div [style "margin-left" "10%", style "margin-top" "5em"
        ,style "font-size"  "150%", style "color" "blue"]
        [ model.today
            |> Maybe.map
                (\today ->
                    text <| "Todays date: "
                     ++ Date.format "dd.M.yyyy" today
                )
            |> Maybe.withDefault (text "")

        ,p[][text ("Jassi age "
             ++ (String.fromInt ageMonths)
             ++ " months = " ++ String.fromFloat (toFloat ageMonths/12)
             ++ " years")]
        ]


main : Program () Model Msg
main =
    Browser.element
        { init = \_ -> initialModel
        , view = view
        , update = update
        , subscriptions = \_ -> Sub.none
        }

-- https://ellie-app.com/gY5sFwWQV8Ra1
-- For elm 0.19, do install with command 
-- elm install justinmimbs/date 
-- the package justinmimbs/date  4.0.1
-- documented at https://package.elm-lang.org/packages/justinmimbs/date/4.0.1
