module TailCall exposing (main)

import Browser
import Html exposing (..)
import Html.Attributes exposing (..)
-- File tail-call-factorial.elm 
-- Inspired by the article at 
-- https://functional-programming-in-elm.netlify.app/recursion/tail-call-elimination.html
-- J. Lammi 14. July 2021

factorialHelp : Int -> Int -> Int
factorialHelp n productSoFar =
   if (n <= 1) then productSoFar
   else (factorialHelp (n - 1) (n * productSoFar))

factorial : Int -> Int
factorial n =
  factorialHelp n 1

rawlist = List.range 1 10 |> List.map (\x -> " Factorial "
  ++ String.fromInt x ++ "! = " 
  ++ String.fromInt (factorial x)) 

blist = List.map (\w -> p [] [text w]) rawlist

main = div [style "font-size" "1.5em",
            style "color" "blue", style "margin-left" "20%",
            style "margin-right" "20%"] blist 
    
