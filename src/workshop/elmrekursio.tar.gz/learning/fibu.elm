module Main exposing (main)

import Browser
import Html exposing (div, p, text)

fizzBuzz = "FizzBuzz"
fizz = "Fizz"
buzz = "Buzz"

fizzBuzzInput value =
    if modBy 15 value == 0 then
        fizzBuzz ++ "=" ++ String.fromInt(value)
    else if modBy 5 value == 0 then
        buzz ++  "=" ++ String.fromInt(value)
    else if modBy 3 value == 0 then
        fizz  ++  "=" ++ String.fromInt(value)
    else (String.fromInt value)


view =
     [ text (fizzBuzzInput 21 )
     , p [] 
     [ text (fizzBuzzInput  10 )] 
     , text (fizzBuzzInput 105 ) 
     ]
 
main = 
    div []  view 

