---- Elm 0.19.1 ------------------------------------------------------------
Say :help for help and :exit to exit! More at <https://elm-lang.org/0.19.1/repl>
----------------------------------------------------------------------------
> List.partition (\x -> remainderBy 2 x == 0) (List.range 1 10)
([2,4,6,8,10],[1,3,5,7,9])
    : ( List Int, List Int )
> List.partition (\x -> remainderBy 2 x > 0) (List.range 1 10)
([1,3,5,7,9],[2,4,6,8,10])
    : ( List Int, List Int )

> List.foldl (\x accu -> x + accu) 0 (List.range 1 10)
55 : Int
List.foldl (+) 0 (List.range 1 10)
55 : Int
List.foldl (*) 1 [1,2,3,4]
24 : number
List.foldl (++) "" ["Dresden",", ", "Hamburg","German cities: "]
"German cities: Hamburg, Dresden" : String
> List.foldr (++) "" ["German cities: ", "Dresden",", ", "Hamburg"]
"German cities: Dresden, Hamburg" : String

> "URL https://elmprogramming.com/list.html"
"URL https://elmprogramming.com/list.html" : String
> :exit

