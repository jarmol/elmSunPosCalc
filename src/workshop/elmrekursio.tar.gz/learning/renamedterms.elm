module Main exposing(..)

-- A text input for reversing text. Very useful!
-- Read how it works:
--   https://guide.elm-lang.org/architecture/text_fields.html

import Browser
import Html exposing (Html, Attribute, div, input, text)
import Html.Attributes exposing (..)
import Html.Events exposing (onInput)


-- MAIN

-- Huom. funktioille init, update ja view voi antaa omat nimet
-- Katso alkuperäinen
-- https://elm-lang.org/examples/text-fields

main =
  Browser.sandbox { init = preset, update = revise, view = monitor }


-- MODEL
-- Model uudelleen nimetty -> State
-- content -> intext

type alias State =
  { intext : String
  }

preset : State
preset =
  { intext = "Kissa söi kielen!" }


-- UPDATE
-- Renamed Msg -> Message
--         Change -> Create

type Message
  = Create String

revise : Message -> State -> State
revise message state =
  case message of
    Create newContent ->
      { state | intext = newContent }


-- VIEW

monitor : State -> Html Message
monitor state =
  div []
    [ input [ placeholder "Text to reverse",
    value state.intext, onInput Create ] []
    , div [] [ text (String.reverse state.intext) ]
    , div [] [ text (String.fromInt (String.length state.intext)) ]
    ]
