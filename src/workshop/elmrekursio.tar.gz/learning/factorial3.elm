module Main exposing (main)

import Browser
import Html exposing (..)
import Html.Attributes exposing (..)



-- rekursion avulla tulo ilman looppia


factorial : Int -> Int
factorial n =
    if n <= 0 then
        1

    else
        n * factorial (n - 1)


workhorse n =
    p [ style "color" "red" ]
        [ text (String.fromInt n ++ "! = " ++ String.fromInt (factorial n)) ]


main =
    div [ style "background" "black" ]
        [ div
            [ style "margin-left" "10%"
            , style "font-size" "1.5em"
            , style "background" "black"
            ]
            [ p [ style "color" "gold" ] [ text "Kertomat" ]
            , workhorse 1
            , workhorse 2
            , workhorse 3
            , workhorse 4
            , workhorse 5
            , workhorse 6
            , workhorse 7
            , workhorse 8
            , workhorse 9
            , workhorse 10
            , workhorse 11
            , workhorse 12
            ]
        ]
